# Cara membuat APK langsung dari HP Android

Project ini sudah dilengkapi GitHub Actions untuk membangun APK secara otomatis di server GitHub.

1. Buat akun/login GitHub di Chrome HP.
2. Buat repository baru, misalnya `KasirSembako`.
3. Upload semua isi folder project ini ke repository. Pastikan folder `.github/workflows/build-apk.yml` ikut ter-upload.
4. Buka tab **Actions** pada repository.
5. Pilih workflow **Build APK**, lalu tekan **Run workflow**. Atau lakukan push ke branch `main`.
6. Setelah selesai, buka workflow yang berhasil dan bagian **Artifacts**.
7. Download `KasirSembako-debug-apk` ke HP.
8. Ekstrak ZIP artifact, lalu buka `app-debug.apk` dan izinkan pemasangan dari sumber tersebut jika Android memintanya.

Catatan: APK debug ditujukan untuk pemakaian/testing. Untuk distribusi publik/Play Store diperlukan release build dan signing key.
