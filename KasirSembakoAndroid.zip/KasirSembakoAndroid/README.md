# Kasir Sembako Android

Aplikasi kasir sederhana untuk toko sembako, dibuat dengan Kotlin + Jetpack Compose.

Fitur versi awal:
- Kasir/transaksi penjualan
- Pencarian produk
- Keranjang dan total otomatis
- Stok berkurang setelah transaksi
- Daftar produk
- Tambah produk (nama, harga beli, harga jual, stok)
- Hapus produk
- Rupiah Indonesia
- Tampilan ringan untuk Android

## Cara menjalankan
1. Buka folder ini dengan Android Studio.
2. Tunggu Gradle selesai sync.
3. Jalankan pada emulator atau HP Android.
4. Untuk membuat APK: Build > Build APK(s).

Catatan: versi awal ini menyimpan data selama aplikasi aktif. Database permanen, riwayat transaksi, laporan omzet/laba, cetak struk, dan backup bisa ditambahkan pada versi berikutnya.
