package com.example.kasirsembako

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.util.Locale

data class Product(val id: Int, val name: String, val buy: Long, val sell: Long, val stock: Int)

private fun rupiah(n: Long): String =
    NumberFormat.getCurrencyInstance(Locale("id","ID")).format(n).replace(",00","")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KasirApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KasirApp() {
    var products by remember {
        mutableStateOf(listOf(
            Product(1,"Beras 5 Kg",65000,72000,20),
            Product(2,"Minyak Goreng 1 L",16000,19000,30),
            Product(3,"Gula 1 Kg",15000,18000,25),
            Product(4,"Telur 1 Kg",27000,31000,15),
            Product(5,"Mie Instan",2500,3500,50)
        ))
    }
    var cart by remember { mutableStateOf(mutableMapOf<Int,Int>()) }
    var tab by remember { mutableStateOf(0) }
    var search by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var buy by remember { mutableStateOf("") }
    var sell by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("") }

    val filtered = products.filter { it.name.contains(search, true) }
    val total = cart.entries.sumOf { (id, qty) ->
        (products.find { it.id == id }?.sell ?: 0L) * qty
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Kasir Sembako", fontWeight = FontWeight.Bold) }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab==0,{tab=0},{ Icon(Icons.Default.ShoppingCart,null); Text("Kasir") })
                NavigationBarItem(tab==1,{tab=1},{ Icon(Icons.Default.Inventory,null); Text("Produk") })
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(12.dp)) {
            if (tab == 0) {
                OutlinedTextField(search,{search=it},Modifier.fillMaxWidth(),
                    label={Text("Cari barang")}, leadingIcon={Icon(Icons.Default.Search,null)})
                Spacer(Modifier.height(10.dp))
                LazyColumn(Modifier.weight(1f)) {
                    items(filtered) { p ->
                        Card(Modifier.fillMaxWidth().padding(vertical=4.dp)) {
                            Row(Modifier.padding(12.dp), verticalAlignment=Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(p.name,fontWeight=FontWeight.Bold)
                                    Text("${rupiah(p.sell)} • Stok ${p.stock}")
                                }
                                IconButton({
                                    val q=cart[p.id] ?: 0
                                    if(q < p.stock) cart=cart.toMutableMap().also{it[p.id]=q+1}
                                }) { Icon(Icons.Default.Add,null) }
                            }
                        }
                    }
                }
                Card(Modifier.fillMaxWidth(), shape=RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Total", style=MaterialTheme.typography.labelLarge)
                        Text(rupiah(total), style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick={
                                if(cart.isNotEmpty()){
                                    products=products.map { p -> p.copy(stock=p.stock-(cart[p.id]?:0)) }
                                    cart=mutableMapOf()
                                }
                            },
                            enabled=cart.isNotEmpty(),
                            Modifier.fillMaxWidth()
                        ){ Text("Bayar / Selesaikan Transaksi") }
                    }
                }
            } else {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Text("Daftar Produk",Modifier.weight(1f),style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
                    Button({showAdd=true}) { Icon(Icons.Default.Add,null); Spacer(Modifier.width(4.dp)); Text("Tambah") }
                }
                Spacer(Modifier.height(8.dp))
                LazyColumn {
                    items(products) { p ->
                        ListItem(
                            headlineContent={Text(p.name)},
                            supportingContent={Text("Beli ${rupiah(p.buy)} • Jual ${rupiah(p.sell)} • Stok ${p.stock}")},
                            trailingContent={IconButton({
                                products=products.filterNot{it.id==p.id}
                            }){Icon(Icons.Default.Delete,null)}}
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }

    if(showAdd){
        AlertDialog(
            onDismissRequest={showAdd=false},
            title={Text("Tambah Produk")},
            text={
                Column {
                    OutlinedTextField(name,{name=it},label={Text("Nama barang")})
                    OutlinedTextField(buy,{buy=it},label={Text("Harga beli")})
                    OutlinedTextField(sell,{sell=it},label={Text("Harga jual")})
                    OutlinedTextField(stock,{stock=it},label={Text("Stok awal")})
                }
            },
            confirmButton={
                TextButton({
                    val b=buy.toLongOrNull(); val s=sell.toLongOrNull(); val st=stock.toIntOrNull()
                    if(name.isNotBlank() && b!=null && s!=null && st!=null){
                        val id=(products.maxOfOrNull{it.id}?:0)+1
                        products=products+Product(id,name,b,s,st)
                        name="";buy="";sell="";stock="";showAdd=false
                    }
                }){Text("Simpan")}
            },
            dismissButton={TextButton({showAdd=false}){Text("Batal")}}
        )
    }
}
